package com.rafiqk.app.nudge

import com.rafiqk.app.data.AzkarData
import com.rafiqk.app.data.Settings
import com.rafiqk.app.prayer.DayTimes
import com.rafiqk.app.prayer.FastReason
import com.rafiqk.app.prayer.HijriCalendar
import com.rafiqk.app.prayer.Prayer
import com.rafiqk.app.prayer.PrayerEngine
import java.time.DayOfWeek
import java.time.LocalDate

/** تنبيه مخطَّط: النوع ووقته ورقم اليوم (0 = اليوم، 1 = غداً) ووسيط اختياري (مشهد الصيام أو اسم الصلاة). */
data class Planned(val kind: NudgeKind, val at: Long, val dayIndex: Int, val arg: String? = null)

/** دالة نقية: تحدد ما يجب جدولته من الإعدادات والأوقات فقط، بلا أي اعتماد على النظام. */
object NudgePlanner {

    private const val MIN = 60_000L

    fun plan(s: Settings, now: Long, days: Int = 2): List<Planned> {
        val out = mutableListOf<Planned>()
        val today = LocalDate.now(s.zone)
        for (i in 0 until days) {
            val t = PrayerEngine.day(s, today.plusDays(i.toLong())) ?: continue
            planDay(s, t, i, out)
        }
        return out.filter { it.at > now + 3_000L }.sortedBy { it.at }
    }

    private fun planDay(s: Settings, t: DayTimes, i: Int, out: MutableList<Planned>) {
        if (s.lastThird) out += Planned(NudgeKind.LAST_THIRD, t.lastThird, i)

        if (s.afterFajr) {
            val first = t.fajr + s.afterFajrDelayMin * MIN
            out += Planned(NudgeKind.AFTER_FAJR, first, i)
            val follow = t.sunrise - 20 * MIN
            if (follow > first + 15 * MIN) out += Planned(NudgeKind.FAJR_FOLLOWUP, follow, i)
        }

        if (s.eveningAzkar) {
            out += Planned(NudgeKind.EVENING_AZKAR, t.asr + (t.maghrib - t.asr) / 2, i)
        }

        if (s.beforeIftar && HijriCalendar.fastReason(t.date) != null) {
            out += Planned(NudgeKind.BEFORE_IFTAR, t.maghrib - 15 * MIN, i)
        }

        if (s.fastEve) {
            val tomorrow = HijriCalendar.fastReason(t.date.plusDays(1))
            if (tomorrow == FastReason.MON_THU || tomorrow == FastReason.WHITE_DAY) {
                val scene = if (tomorrow == FastReason.WHITE_DAY) AzkarData.FAST_WHITE else AzkarData.FAST_MON_THU
                out += Planned(NudgeKind.FAST_EVE, t.isha + 10 * MIN, i, scene)
            }
        }

        if (t.date.dayOfWeek == DayOfWeek.FRIDAY) {
            if (s.friday) out += Planned(NudgeKind.FRIDAY_HOUR, t.maghrib - 60 * MIN, i)
            if (s.kahf) out += Planned(NudgeKind.KAHF, t.sunrise + 30 * MIN, i)
        }

        if (s.adhanSound) {
            for (p in Prayer.entries) {
                val kind = adhanKind(p) ?: continue
                out += Planned(kind, t.time(p), i, p.name)
            }
        }
    }

    private fun adhanKind(p: Prayer): NudgeKind? = when (p) {
        Prayer.FAJR -> NudgeKind.ADHAN_FAJR
        Prayer.DHUHR -> NudgeKind.ADHAN_DHUHR
        Prayer.ASR -> NudgeKind.ADHAN_ASR
        Prayer.MAGHRIB -> NudgeKind.ADHAN_MAGHRIB
        Prayer.ISHA -> NudgeKind.ADHAN_ISHA
        Prayer.SUNRISE -> null
    }
}
