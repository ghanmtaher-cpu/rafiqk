package com.rafiqk.app.data

import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

data class City(val name: String, val lat: Double, val lon: Double, val tz: String) {
    fun toGeo() = GeoPoint(lat, lon, tz, name)
}

object Cities {

    val all: List<City> = listOf(
        City("مكة المكرمة", 21.4225, 39.8262, "Asia/Riyadh"),
        City("المدينة المنورة", 24.4686, 39.6142, "Asia/Riyadh"),
        City("الرياض", 24.7136, 46.6753, "Asia/Riyadh"),
        City("جدة", 21.4858, 39.1925, "Asia/Riyadh"),
        City("الدمام", 26.4207, 50.0888, "Asia/Riyadh"),
        City("القاهرة", 30.0444, 31.2357, "Africa/Cairo"),
        City("الإسكندرية", 31.2001, 29.9187, "Africa/Cairo"),
        City("الخرطوم", 15.5007, 32.5599, "Africa/Khartoum"),
        City("طرابلس", 32.8872, 13.1913, "Africa/Tripoli"),
        City("تونس", 36.8065, 10.1815, "Africa/Tunis"),
        City("الجزائر", 36.7538, 3.0588, "Africa/Algiers"),
        City("الرباط", 34.0209, -6.8416, "Africa/Casablanca"),
        City("الدار البيضاء", 33.5731, -7.5898, "Africa/Casablanca"),
        City("نواكشوط", 18.0735, -15.9582, "Africa/Nouakchott"),
        City("القدس", 31.7683, 35.2137, "Asia/Jerusalem"),
        City("غزة", 31.5017, 34.4668, "Asia/Gaza"),
        City("عمّان", 31.9454, 35.9284, "Asia/Amman"),
        City("دمشق", 33.5138, 36.2765, "Asia/Damascus"),
        City("بيروت", 33.8938, 35.5018, "Asia/Beirut"),
        City("بغداد", 33.3152, 44.3661, "Asia/Baghdad"),
        City("الكويت", 29.3759, 47.9774, "Asia/Kuwait"),
        City("المنامة", 26.2235, 50.5876, "Asia/Bahrain"),
        City("الدوحة", 25.2854, 51.5310, "Asia/Qatar"),
        City("أبوظبي", 24.4539, 54.3773, "Asia/Dubai"),
        City("دبي", 25.2048, 55.2708, "Asia/Dubai"),
        City("مسقط", 23.5880, 58.3829, "Asia/Muscat"),
        City("صنعاء", 15.3694, 44.1910, "Asia/Aden"),
        City("إسطنبول", 41.0082, 28.9784, "Europe/Istanbul"),
        City("أنقرة", 39.9334, 32.8597, "Europe/Istanbul"),
        City("طهران", 35.6892, 51.3890, "Asia/Tehran"),
        City("كراتشي", 24.8607, 67.0011, "Asia/Karachi"),
        City("لاهور", 31.5204, 74.3587, "Asia/Karachi"),
        City("إسلام آباد", 33.6844, 73.0479, "Asia/Karachi"),
        City("دكا", 23.8103, 90.4125, "Asia/Dhaka"),
        City("جاكرتا", -6.2088, 106.8456, "Asia/Jakarta"),
        City("كوالالمبور", 3.1390, 101.6869, "Asia/Kuala_Lumpur"),
        City("لندن", 51.5072, -0.1276, "Europe/London"),
        City("باريس", 48.8566, 2.3522, "Europe/Paris"),
        City("برلين", 52.5200, 13.4050, "Europe/Berlin"),
        City("نيويورك", 40.7128, -74.0060, "America/New_York"),
        City("تورنتو", 43.6532, -79.3832, "America/Toronto"),
        City("لوس أنجلوس", 34.0522, -118.2437, "America/Los_Angeles"),
        City("سيدني", -33.8688, 151.2093, "Australia/Sydney"),
    )

    /** أقرب مدينة معروفة مع المسافة بالكيلومتر. */
    fun nearest(lat: Double, lon: Double): Pair<City, Double> =
        all.map { it to distanceKm(lat, lon, it.lat, it.lon) }.minBy { it.second }

    private fun distanceKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2) * sin(dLat / 2) +
            cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2) * sin(dLon / 2)
        return 2 * r * asin(sqrt(a))
    }
}
