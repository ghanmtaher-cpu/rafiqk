package com.rafiqk.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.rafiqk.app.data.AppStore
import com.rafiqk.app.nudge.Scheduler
import com.rafiqk.app.ui.RafiqkRoot
import com.rafiqk.app.ui.theme.RafiqkTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {

    /** يزيد عند كل عودة للتطبيق، فتُعاد قراءة حالة الأذونات بعد رجوع المستخدم من إعدادات النظام. */
    private var resumeTick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val store = AppStore.get(this)

        // أول قيمة عند كل ظهور للتطبيق + كل تغيير في الإعدادات => إعادة جدولة كاملة
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                store.settings.collect {
                    withContext(Dispatchers.Default) { Scheduler.rescheduleAll(applicationContext) }
                }
            }
        }

        setContent {
            RafiqkTheme {
                RafiqkRoot(store = store, refreshKey = resumeTick)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        resumeTick++
    }
}
