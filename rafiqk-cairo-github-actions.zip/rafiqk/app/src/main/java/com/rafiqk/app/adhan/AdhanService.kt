package com.rafiqk.app.adhan

import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.rafiqk.app.R
import com.rafiqk.app.nudge.Notifier
import com.rafiqk.app.prayer.Prayer

/** خدمة أمامية قصيرة تبقي العملية حيّة طوال تشغيل الصوت، مع زر إيقاف في الإشعار. */
class AdhanService : Service() {

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            finish()
            return START_NOT_STICKY
        }
        Notifier.ensureChannels(this)
        val prayer = intent?.getStringExtra(EXTRA_PRAYER)
            ?.let { runCatching { Prayer.valueOf(it) }.getOrNull() }
        val name = prayer?.let { getString(it.label) }.orEmpty()

        val stop = PendingIntent.getService(
            this, 0, Intent(this, AdhanService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val notification = NotificationCompat.Builder(this, Notifier.CH_ADHAN)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(ContextCompat.getColor(this, R.color.brand))
            .setContentTitle(getString(R.string.adhan_title, name))
            .setOngoing(true)
            .setSilent(true)
            .addAction(0, getString(R.string.adhan_stop), stop)
            .build()

        try {
            ServiceCompat.startForeground(
                this, NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK,
            )
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        AdhanPlayer.play(this) { finish() }
        return START_NOT_STICKY
    }

    private fun finish() {
        AdhanPlayer.stop()
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        AdhanPlayer.stop()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val EXTRA_PRAYER = "prayer"
        const val ACTION_STOP = "com.rafiqk.app.ADHAN_STOP"
        private const val NOTIF_ID = 3001
    }
}
