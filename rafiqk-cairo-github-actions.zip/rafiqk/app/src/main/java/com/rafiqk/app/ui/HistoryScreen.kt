package com.rafiqk.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.rafiqk.app.R
import com.rafiqk.app.data.AppStore
import com.rafiqk.app.data.Streaks
import com.rafiqk.app.util.ar
import java.time.LocalDate
import java.time.YearMonth

private val MONTHS = arrayOf(
    "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
    "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر",
)

// الأسبوع يبدأ بالسبت: سبت أحد اثنين ثلاثاء أربعاء خميس جمعة
private val WEEK_LETTERS = arrayOf("س", "ح", "ن", "ث", "ر", "خ", "ج")

@Composable
fun HistoryScreen(store: AppStore) {
    val settings by store.settings.collectAsState()
    val done by store.doneDates.collectAsState()
    val today = LocalDate.now(settings.zone)
    val thisMonth = YearMonth.from(today)
    var month by remember { mutableStateOf(thisMonth) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        ScreenTitle(stringResource(R.string.history_title), stringResource(R.string.history_hint))

        RCard {
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly) {
                StatBlock(daysText(Streaks.current(done, today)), stringResource(R.string.streak_current), Modifier.weight(1f))
                StatBlock(
                    daysText(Streaks.best(done)), stringResource(R.string.streak_best), Modifier.weight(1f),
                    valueColor = MaterialTheme.colorScheme.secondary,
                )
                StatBlock(done.size.ar(), stringResource(R.string.streak_total), Modifier.weight(1f))
            }
        }

        RCard {
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                IconButton(onClick = { month = month.minusMonths(1) }) {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = stringResource(R.string.prev_month))
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        "${MONTHS[month.monthValue - 1]} ${month.year.ar()}",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    )
                    Text(
                        stringResource(R.string.month_count, Streaks.inMonth(done, month).ar(), month.lengthOfMonth().ar()),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                IconButton(onClick = { month = month.plusMonths(1) }, enabled = month.isBefore(thisMonth)) {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = stringResource(R.string.next_month))
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth()) {
                for (letter in WEEK_LETTERS) {
                    Text(
                        letter,
                        Modifier.weight(1f),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            Spacer(Modifier.height(4.dp))
            MonthGrid(month, done, today) { date, isDone -> store.setDone(date, !isDone) }
        }
    }
}

@Composable
private fun MonthGrid(month: YearMonth, done: Set<LocalDate>, today: LocalDate, onToggle: (LocalDate, Boolean) -> Unit) {
    // سبت = 0 … جمعة = 6
    val lead = (month.atDay(1).dayOfWeek.value + 1) % 7
    val days = month.lengthOfMonth()
    val rows = (lead + days + 6) / 7
    for (r in 0 until rows) {
        Row(Modifier.fillMaxWidth()) {
            for (c in 0 until 7) {
                val dayNum = r * 7 + c - lead + 1
                Box(Modifier.weight(1f).aspectRatio(1f).padding(3.dp), contentAlignment = Alignment.Center) {
                    if (dayNum in 1..days) {
                        val date = month.atDay(dayNum)
                        DayCell(date, date in done, date == today, date.isAfter(today)) { onToggle(date, date in done) }
                    }
                }
            }
        }
    }
}

@Composable
private fun DayCell(date: LocalDate, isDone: Boolean, isToday: Boolean, future: Boolean, onClick: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    val textColor = when {
        isDone -> scheme.onPrimary
        future -> scheme.onSurfaceVariant.copy(alpha = 0.4f)
        else -> scheme.onSurface
    }
    Box(
        Modifier
            .fillMaxSize()
            .clip(CircleShape)
            .background(if (isDone) scheme.primary else Color.Transparent)
            .then(if (isToday) Modifier.border(2.dp, scheme.secondary, CircleShape) else Modifier)
            .clickable(enabled = !future, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(date.dayOfMonth.ar(), color = textColor, style = MaterialTheme.typography.labelLarge)
    }
}
