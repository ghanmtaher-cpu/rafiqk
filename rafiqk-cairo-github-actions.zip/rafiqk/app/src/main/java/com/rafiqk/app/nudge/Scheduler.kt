package com.rafiqk.app.nudge

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.rafiqk.app.data.AppStore
import java.time.LocalDate
import java.time.ZoneId

/**
 * يجدول تنبيهات يومين قادمين، ويعيد التخطيط عند: فتح التطبيق، تغيير الإعدادات، الإقلاع،
 * تغيّر الوقت أو المنطقة، وبعد كل تنبيه، وبمنبّه صيانة بعد منتصف الليل.
 */
object Scheduler {

    private const val MAINTENANCE_CODE = 9999
    private const val MAX_DAYS = 3

    fun rescheduleAll(context: Context) {
        val app = context.applicationContext
        val am = app.getSystemService(AlarmManager::class.java) ?: return
        cancelAll(app, am)
        val s = AppStore.get(app).settings.value
        if (s.location != null) {
            NudgePlanner.plan(s, System.currentTimeMillis()).forEach { p ->
                val pi = pending(app, p.kind, p.dayIndex, p.arg, PendingIntent.FLAG_UPDATE_CURRENT) ?: return@forEach
                setAlarm(am, p.at, pi, exact = true)
            }
        }
        scheduleMaintenance(app, am)
    }

    private fun cancelAll(ctx: Context, am: AlarmManager) {
        for (kind in NudgeKind.entries) {
            for (day in 0 until MAX_DAYS) {
                pending(ctx, kind, day, null, PendingIntent.FLAG_NO_CREATE)?.let {
                    am.cancel(it)
                    it.cancel()
                }
            }
        }
    }

    private fun pending(ctx: Context, kind: NudgeKind, day: Int, arg: String?, flags: Int): PendingIntent? {
        val intent = Intent(ctx, NudgeReceiver::class.java)
            .putExtra(NudgeReceiver.EXTRA_KIND, kind.id)
        if (arg != null) intent.putExtra(NudgeReceiver.EXTRA_ARG, arg)
        return PendingIntent.getBroadcast(
            ctx, kind.code + day * 1000, intent, flags or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    private fun setAlarm(am: AlarmManager, at: Long, pi: PendingIntent, exact: Boolean) {
        try {
            if (exact && (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms())) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    private fun scheduleMaintenance(ctx: Context, am: AlarmManager) {
        val zone = ZoneId.systemDefault()
        val at = LocalDate.now(zone).plusDays(1).atTime(0, 5).atZone(zone).toInstant().toEpochMilli()
        val pi = PendingIntent.getBroadcast(
            ctx, MAINTENANCE_CODE, Intent(ctx, RescheduleReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        setAlarm(am, at, pi, exact = false)
    }
}
