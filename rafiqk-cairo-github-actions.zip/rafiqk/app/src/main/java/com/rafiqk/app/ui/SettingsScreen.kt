package com.rafiqk.app.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings as AndroidSettings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.rafiqk.app.R
import com.rafiqk.app.data.AppStore
import com.rafiqk.app.data.Settings
import com.rafiqk.app.nudge.NudgeKind
import com.rafiqk.app.nudge.Notifier
import com.rafiqk.app.nudge.PermissionStatus
import com.rafiqk.app.prayer.Prayer
import com.rafiqk.app.util.ar
import com.rafiqk.app.util.toArabicDigits
import kotlin.math.roundToInt

private val METHODS = listOf(
    "UMM_AL_QURA" to R.string.method_umm_al_qura,
    "EGYPTIAN" to R.string.method_egyptian,
    "MUSLIM_WORLD_LEAGUE" to R.string.method_mwl,
    "KARACHI" to R.string.method_karachi,
    "NORTH_AMERICA" to R.string.method_isna,
    "KUWAIT" to R.string.method_kuwait,
    "QATAR" to R.string.method_qatar,
)

@Composable
fun SettingsScreen(store: AppStore, refreshKey: Int) {
    val ctx = LocalContext.current
    val s by store.settings.collectAsState()
    fun update(block: (Settings) -> Settings) = store.updateSettings(block)

    val notifOk = remember(refreshKey) { PermissionStatus.notificationsOk(ctx) }
    val exactOk = remember(refreshKey) { PermissionStatus.exactAlarmsOk(ctx) }

    val gps = rememberGpsAction(store)
    var showCities by remember { mutableStateOf(false) }
    var showMethods by remember { mutableStateOf(false) }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (!granted) openNotificationSettings(ctx)
    }

    var delayState by remember(s.afterFajrDelayMin) { mutableFloatStateOf(s.afterFajrDelayMin.toFloat()) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        ScreenTitle(stringResource(R.string.settings_title))

        // ——— الموقع
        Section(stringResource(R.string.settings_location)) {
            val label = s.location?.label.orEmpty().ifBlank { stringResource(R.string.my_location) }
            Text(
                if (s.location == null) stringResource(R.string.location_not_set) else label,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            )
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = gps.run, enabled = !gps.busy, shape = RoundedCornerShape(14.dp)) {
                    Text(stringResource(if (gps.busy) R.string.location_busy else R.string.setup_gps))
                }
                OutlinedButton(onClick = { showCities = true }, shape = RoundedCornerShape(14.dp)) {
                    Text(stringResource(R.string.setup_city))
                }
            }
        }

        // ——— طريقة الحساب
        Section(stringResource(R.string.settings_calc)) {
            val methodLabel = METHODS.firstOrNull { it.first == s.method }?.second ?: R.string.method_umm_al_qura
            Row(
                Modifier.fillMaxWidth().clickable { showMethods = true }.padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(stringResource(R.string.settings_method), style = MaterialTheme.typography.titleSmall)
                    Text(
                        stringResource(methodLabel),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.secondary,
                    )
                }
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            Spacer(Modifier.height(10.dp))
            Text(stringResource(R.string.settings_asr), style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
                FilterChip(
                    selected = !s.hanafi,
                    onClick = { update { it.copy(hanafi = false) } },
                    label = { Text(stringResource(R.string.asr_standard)) },
                )
                FilterChip(
                    selected = s.hanafi,
                    onClick = { update { it.copy(hanafi = true) } },
                    label = { Text(stringResource(R.string.asr_hanafi)) },
                )
            }
        }

        // ——— التذكيرات
        Section(stringResource(R.string.settings_nudges)) {
            SwitchRow(stringResource(R.string.set_last_third), stringResource(R.string.set_last_third_sub), s.lastThird) { v ->
                update { it.copy(lastThird = v) }
            }
            SwitchRow(stringResource(R.string.set_after_fajr), stringResource(R.string.set_after_fajr_sub), s.afterFajr) { v ->
                update { it.copy(afterFajr = v) }
            }
            if (s.afterFajr) {
                Text(
                    stringResource(R.string.set_delay, s.afterFajrDelayMin.ar()),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Slider(
                    value = delayState,
                    onValueChange = { delayState = it },
                    onValueChangeFinished = {
                        val minutes = (delayState / 5f).roundToInt() * 5
                        update { it.copy(afterFajrDelayMin = minutes) }
                    },
                    valueRange = 5f..60f,
                    steps = 10,
                )
            }
            SwitchRow(stringResource(R.string.set_evening), stringResource(R.string.set_evening_sub), s.eveningAzkar) { v ->
                update { it.copy(eveningAzkar = v) }
            }
            SwitchRow(stringResource(R.string.set_iftar), stringResource(R.string.set_iftar_sub), s.beforeIftar) { v ->
                update { it.copy(beforeIftar = v) }
            }
            SwitchRow(stringResource(R.string.set_fast_eve), stringResource(R.string.set_fast_eve_sub), s.fastEve) { v ->
                update { it.copy(fastEve = v) }
            }
            SwitchRow(stringResource(R.string.set_friday), stringResource(R.string.set_friday_sub), s.friday) { v ->
                update { it.copy(friday = v) }
            }
            SwitchRow(stringResource(R.string.set_kahf), stringResource(R.string.set_kahf_sub), s.kahf) { v ->
                update { it.copy(kahf = v) }
            }
            SwitchRow(stringResource(R.string.set_adhan), stringResource(R.string.set_adhan_sub), s.adhanSound) { v ->
                update { it.copy(adhanSound = v) }
            }
        }

        // ——— الأذونات
        Section(stringResource(R.string.settings_permissions)) {
            StatusRow(
                title = stringResource(R.string.perm_notifications),
                ok = notifOk,
                actionLabel = stringResource(R.string.perm_enable),
            ) {
                if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                else openNotificationSettings(ctx)
            }
            if (Build.VERSION.SDK_INT >= 31) {
                StatusRow(
                    title = stringResource(R.string.perm_exact),
                    ok = exactOk,
                    actionLabel = stringResource(R.string.perm_enable),
                ) {
                    safeStart(ctx, Intent(AndroidSettings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${ctx.packageName}")))
                }
            }
            StatusRow(
                title = stringResource(R.string.perm_battery),
                ok = false,
                actionLabel = stringResource(R.string.perm_open),
                showStatus = false,
            ) {
                safeStart(ctx, Intent(AndroidSettings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
            Text(
                stringResource(R.string.perm_battery_note),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp),
            )
        }

        // ——— تجربة
        Section(stringResource(R.string.settings_test)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { Notifier.showNudge(ctx, NudgeKind.AFTER_FAJR, null) },
                    shape = RoundedCornerShape(14.dp),
                ) { Text(stringResource(R.string.test_notification)) }
                OutlinedButton(
                    onClick = { Notifier.startAdhan(ctx, Prayer.DHUHR.name) },
                    shape = RoundedCornerShape(14.dp),
                ) { Text(stringResource(R.string.test_adhan)) }
            }
        }

        // ——— حول
        Section(stringResource(R.string.settings_about)) {
            Text(
                stringResource(R.string.about_version, versionName(ctx).toArabicDigits()),
                style = MaterialTheme.typography.bodyMedium,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                stringResource(R.string.about_disclaimer),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Spacer(Modifier.height(8.dp))
    }

    if (showCities) {
        CityPickerDialog(
            onPick = { c -> update { it.copy(location = c.toGeo()) } },
            onDismiss = { showCities = false },
        )
    }
    if (showMethods) {
        MethodDialog(
            selected = s.method,
            onSelect = { id -> update { it.copy(method = id) } },
            onDismiss = { showMethods = false },
        )
    }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column {
        Text(
            title,
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.secondary,
            modifier = Modifier.padding(bottom = 8.dp, start = 4.dp),
        )
        RCard(content = content)
    }
}

@Composable
private fun SwitchRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun StatusRow(title: String, ok: Boolean, actionLabel: String, showStatus: Boolean = true, onAction: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            if (showStatus) {
                Text(
                    stringResource(if (ok) R.string.perm_on else R.string.perm_off),
                    style = MaterialTheme.typography.bodySmall,
                    color = if (ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                )
            }
        }
        if (!ok) TextButton(onClick = onAction) { Text(actionLabel) }
    }
}

@Composable
private fun MethodDialog(selected: String, onSelect: (String) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.close)) } },
        title = { Text(stringResource(R.string.settings_method)) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                for ((id, label) in METHODS) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable {
                                onSelect(id)
                                onDismiss()
                            }
                            .padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = id == selected, onClick = null)
                        Spacer(Modifier.width(10.dp))
                        Text(stringResource(label))
                    }
                }
            }
        },
    )
}

private fun openNotificationSettings(ctx: Context) {
    safeStart(
        ctx,
        Intent(AndroidSettings.ACTION_APP_NOTIFICATION_SETTINGS)
            .putExtra(AndroidSettings.EXTRA_APP_PACKAGE, ctx.packageName),
    )
}

private fun safeStart(ctx: Context, intent: Intent) {
    runCatching { ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}

private fun versionName(ctx: Context): String =
    runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull().orEmpty()
