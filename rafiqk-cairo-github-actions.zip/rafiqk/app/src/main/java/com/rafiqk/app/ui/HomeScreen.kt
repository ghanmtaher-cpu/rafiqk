package com.rafiqk.app.ui

import android.text.format.DateFormat
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.rafiqk.app.R
import com.rafiqk.app.data.AppStore
import com.rafiqk.app.data.AzkarData
import com.rafiqk.app.data.Settings
import com.rafiqk.app.data.Streaks
import com.rafiqk.app.nudge.PermissionStatus
import com.rafiqk.app.prayer.HijriCalendar
import com.rafiqk.app.prayer.Prayer
import com.rafiqk.app.prayer.PrayerEngine
import com.rafiqk.app.prayer.PrayerWindow
import com.rafiqk.app.util.ar
import com.rafiqk.app.util.formatClock
import com.rafiqk.app.util.formatCountdown
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

private val Gold = Color(0xFFE3B94F)

@Composable
fun HomeScreen(store: AppStore, refreshKey: Int, onOpenSettings: () -> Unit) {
    val ctx = LocalContext.current
    val settings by store.settings.collectAsState()
    val done by store.doneDates.collectAsState()

    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(1000L - now % 1000L)
        }
    }

    val zone = settings.zone
    val today = LocalDate.now(zone)
    val window = remember(settings, today) { PrayerEngine.window(settings, today) }
    val use24 = remember { DateFormat.is24HourFormat(ctx) }
    val permissionIssue = remember(refreshKey) {
        !PermissionStatus.notificationsOk(ctx) || !PermissionStatus.exactAlarmsOk(ctx)
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        ScreenTitle(stringResource(R.string.app_name), stringResource(R.string.app_tagline))

        if (permissionIssue) PermissionBanner(onFix = onOpenSettings)

        when {
            settings.location == null -> SetupCard(store)
            window == null -> RCard {
                Text(stringResource(R.string.calc_failed), style = MaterialTheme.typography.bodyLarge)
            }
            else -> {
                val hijriDate = if (now >= window.today.maghrib) today.plusDays(1) else today
                Hero(window, now, settings, HijriCalendar.format(hijriDate), use24)
                MissionCard(store, window, now, today, today in done)
                DhikrCard(now, zone)
                StreakCard(done, today)
                TimesCard(window, now, zone, use24)
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun SetupCard(store: AppStore) {
    val gps = rememberGpsAction(store)
    var showCities by remember { mutableStateOf(false) }
    RCard {
        Text(
            stringResource(R.string.setup_title),
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
        )
        Spacer(Modifier.height(8.dp))
        Text(
            stringResource(R.string.setup_body),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = gps.run,
            enabled = !gps.busy,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().height(52.dp),
        ) {
            Text(stringResource(if (gps.busy) R.string.location_busy else R.string.setup_gps))
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(
            onClick = { showCities = true },
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().height(52.dp),
        ) { Text(stringResource(R.string.setup_city)) }
    }
    if (showCities) {
        CityPickerDialog(
            onPick = { c -> store.updateSettings { it.copy(location = c.toGeo()) } },
            onDismiss = { showCities = false },
        )
    }
}

/** العنصر المميّز في الشاشة: الصلاة القادمة وعدّاد تنازلي بصوت هادئ وبقية الشاشة تخدمه. */
@Composable
private fun Hero(window: PrayerWindow, now: Long, settings: Settings, hijri: String?, use24: Boolean) {
    val zone = settings.zone
    val next = window.next(now)
    val prev = window.previous(now)
    val city = settings.location?.label.orEmpty().ifBlank { stringResource(R.string.my_location) }

    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF117356), Color(0xFF083828))))
            .padding(22.dp),
    ) {
        Column {
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text(city, color = Color.White.copy(alpha = 0.85f), style = MaterialTheme.typography.labelLarge)
                if (hijri != null) Text(hijri, color = Gold, style = MaterialTheme.typography.labelLarge)
            }
            Spacer(Modifier.height(18.dp))
            if (next != null) {
                Text(
                    stringResource(R.string.home_next),
                    color = Color.White.copy(alpha = 0.7f),
                    style = MaterialTheme.typography.labelMedium,
                )
                Text(
                    stringResource(next.first.label),
                    color = Color.White,
                    style = MaterialTheme.typography.displaySmall.copy(fontWeight = FontWeight.Bold),
                )
                Text(
                    formatCountdown(next.second - now),
                    color = Gold,
                    style = MaterialTheme.typography.displayMedium.copy(fontWeight = FontWeight.Bold),
                )
                Spacer(Modifier.height(14.dp))
                if (prev != null && next.second > prev.second) {
                    LinearProgressIndicator(
                        progress = { ((now - prev.second).toFloat() / (next.second - prev.second)).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                        color = Gold,
                        trackColor = Color.White.copy(alpha = 0.18f),
                    )
                    Spacer(Modifier.height(8.dp))
                }
                Text(
                    stringResource(R.string.home_starts_at, formatClock(next.second, zone, use24)),
                    color = Color.White.copy(alpha = 0.8f),
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
        }
    }
}

@Composable
private fun MissionCard(store: AppStore, window: PrayerWindow, now: Long, today: LocalDate, isDone: Boolean) {
    val haptic = LocalHapticFeedback.current
    val t = window.today
    RCard(container = if (isDone) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface) {
        Text(
            stringResource(R.string.mission_title),
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
        )
        Spacer(Modifier.height(4.dp))
        val hint = when {
            isDone -> stringResource(R.string.mission_done)
            now in t.fajr..t.sunrise ->
                stringResource(R.string.mission_before_sunrise, formatCountdown(t.sunrise - now))
            else -> stringResource(R.string.mission_after)
        }
        Text(hint, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(12.dp))
        if (isDone) {
            TextButton(onClick = { store.setDone(today, false) }) { Text(stringResource(R.string.mission_undo)) }
        } else {
            Button(
                onClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    store.setDone(today, true)
                },
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().height(52.dp),
            ) { Text(stringResource(R.string.mission_confirm), style = MaterialTheme.typography.titleSmall) }
        }
    }
}

/** ذكر الصباح أو المساء بحسب وقت اليوم، والضغط على البطاقة يعدّ التكرار. */
@Composable
private fun DhikrCard(now: Long, zone: ZoneId) {
    val haptic = LocalHapticFeedback.current
    val morning = Instant.ofEpochMilli(now).atZone(zone).hour < 12
    val list = remember(morning) { AzkarData.list(if (morning) AzkarData.MORNING else AzkarData.EVENING) }
    var index by remember(morning) { mutableIntStateOf(0) }
    var count by remember(morning) { mutableIntStateOf(0) }
    val item = list.getOrNull(index) ?: return

    val advance: () -> Unit = {
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        if (count < item.repeat) {
            count++
        } else {
            index = (index + 1) % list.size
            count = 0
        }
    }

    RCard(Modifier.clip(RoundedCornerShape(24.dp)).clickable(onClick = advance)) {
        Text(
            stringResource(if (morning) R.string.dhikr_morning else R.string.dhikr_evening),
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.secondary,
        )
        Spacer(Modifier.height(10.dp))
        Text(item.text, style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.height(4.dp))
        Text(item.source, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text(
                "${count.ar()} / ${item.repeat.ar()}",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.primary,
            )
            Text(
                stringResource(if (count < item.repeat) R.string.dhikr_tap_count else R.string.dhikr_tap_next),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun StreakCard(done: Set<LocalDate>, today: LocalDate) {
    val current = Streaks.current(done, today)
    val best = Streaks.best(done)
    RCard {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly) {
            StatBlock(daysText(current), stringResource(R.string.streak_current), Modifier.weight(1f))
            StatBlock(
                daysText(best), stringResource(R.string.streak_best), Modifier.weight(1f),
                valueColor = MaterialTheme.colorScheme.secondary,
            )
        }
        Spacer(Modifier.height(16.dp))
        // الأقدم عند اليمين واليوم عند اليسار، وفق اتجاه القراءة
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
            for (back in 6 downTo 0) {
                val d = today.minusDays(back.toLong())
                DayDot(d.dayOfMonth, d in done, back == 0)
            }
        }
    }
}

@Composable
private fun DayDot(day: Int, done: Boolean, isToday: Boolean) {
    val scheme = MaterialTheme.colorScheme
    Box(
        Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(if (done) scheme.primary else Color.Transparent)
            .border(if (isToday) 2.dp else 1.dp, if (isToday) scheme.secondary else scheme.outlineVariant, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        if (done) {
            Icon(Icons.Filled.Check, contentDescription = null, tint = scheme.onPrimary, modifier = Modifier.size(18.dp))
        } else {
            Text(day.ar(), style = MaterialTheme.typography.labelMedium, color = scheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun TimesCard(window: PrayerWindow, now: Long, zone: ZoneId, use24: Boolean) {
    val next = window.next(now)
    val t = window.today
    RCard {
        Text(
            stringResource(R.string.home_times_title),
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
        )
        Spacer(Modifier.height(6.dp))
        for (p in Prayer.entries) {
            val time = t.time(p)
            TimeRow(
                name = stringResource(p.label),
                clock = formatClock(time, zone, use24),
                highlighted = next != null && next.first == p && next.second == time,
                passed = time < now,
            )
        }
        TimeRow(
            name = stringResource(R.string.prayer_last_third),
            clock = formatClock(t.lastThird, zone, use24),
            highlighted = false,
            passed = t.lastThird < now,
        )
    }
}

@Composable
private fun TimeRow(name: String, clock: String, highlighted: Boolean, passed: Boolean) {
    val scheme = MaterialTheme.colorScheme
    val textColor = when {
        highlighted -> scheme.primary
        passed -> scheme.onSurfaceVariant.copy(alpha = 0.6f)
        else -> scheme.onSurface
    }
    val weight = if (highlighted) FontWeight.Bold else FontWeight.Normal
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(if (highlighted) scheme.primaryContainer else Color.Transparent)
            .padding(horizontal = 12.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(if (highlighted) scheme.primary else scheme.outlineVariant),
        )
        Spacer(Modifier.width(12.dp))
        Text(name, Modifier.weight(1f), color = textColor, fontWeight = weight, style = MaterialTheme.typography.bodyLarge)
        Text(clock, color = textColor, fontWeight = weight, style = MaterialTheme.typography.bodyLarge)
    }
}
