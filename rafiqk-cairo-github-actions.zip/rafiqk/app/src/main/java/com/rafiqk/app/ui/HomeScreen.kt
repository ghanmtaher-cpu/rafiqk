package com.rafiqk.app.ui

import android.text.format.DateFormat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.foundation.Canvas
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.IconButton
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.ui.graphics.drawscope.rotate
import kotlin.math.cos
import kotlin.math.sin
import androidx.compose.foundation.background
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import com.batoulapps.adhan.Coordinates
import com.batoulapps.adhan.Qibla
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.rafiqk.app.R
import com.rafiqk.app.data.AppStore
import com.rafiqk.app.data.AzkarData
import com.rafiqk.app.data.Settings
import com.rafiqk.app.data.Streaks
import com.rafiqk.app.nudge.PermissionStatus
import com.rafiqk.app.prayer.HijriCalendar
import com.rafiqk.app.prayer.Prayer
import com.rafiqk.app.prayer.PrayerEngine
import com.rafiqk.app.prayer.PrayerWindow
import com.rafiqk.app.util.ar
import com.rafiqk.app.util.formatClock
import com.rafiqk.app.util.formatCountdown
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

private val Gold = Color(0xFFE3B94F)

@Composable
fun HomeScreen(store: AppStore, refreshKey: Int, onOpenSettings: () -> Unit) {
    val ctx = LocalContext.current
    val settings by store.settings.collectAsState()
    val done by store.doneDates.collectAsState()

    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(1000L - now % 1000L)
        }
    }

    val zone = settings.zone
    val today = LocalDate.now(zone)
    val window = remember(settings, today) { PrayerEngine.window(settings, today) }
    val use24 = remember { DateFormat.is24HourFormat(ctx) }
    val permissionIssue = remember(refreshKey) {
        !PermissionStatus.notificationsOk(ctx) || !PermissionStatus.exactAlarmsOk(ctx)
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        ScreenTitle(stringResource(R.string.app_name), stringResource(R.string.app_tagline))

        if (permissionIssue) PermissionBanner(onFix = onOpenSettings)

        when {
            settings.location == null -> SetupCard(store)
            window == null -> RCard {
                Text(stringResource(R.string.calc_failed), style = MaterialTheme.typography.bodyLarge)
            }
            else -> {
                val hijriDate = if (now >= window.today.maghrib) today.plusDays(1) else today
                Appear(0) { Hero(window, now, settings, HijriCalendar.format(hijriDate), use24) }
                Appear(1) { TimesCard(window, now, zone, use24, settings, store) }
                Appear(2) { MissionCard(store, window, now, today, today in done) }
                settings.location?.let { loc -> Appear(3) { QiblaCard(loc.lat, loc.lon) } }
                Appear(4) { DhikrCard(now, zone) }
                Appear(5) { StreakCard(done, today) }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun SetupCard(store: AppStore) {
    val gps = rememberGpsAction(store)
    var showCities by remember { mutableStateOf(false) }
    RCard {
        Text(
            stringResource(R.string.setup_title),
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
        )
        Spacer(Modifier.height(8.dp))
        Text(
            stringResource(R.string.setup_body),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = gps.run,
            enabled = !gps.busy,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().height(52.dp),
        ) {
            Text(stringResource(if (gps.busy) R.string.location_busy else R.string.setup_gps))
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(
            onClick = { showCities = true },
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().height(52.dp),
        ) { Text(stringResource(R.string.setup_city)) }
    }
    if (showCities) {
        CityPickerDialog(
            onPick = { c -> store.updateSettings { it.copy(location = c.toGeo()) } },
            onDismiss = { showCities = false },
        )
    }
}

/** العنصر المميّز في الشاشة: الصلاة القادمة وحلقة تقدّم مع عدّاد تنازلي. */
@Composable
private fun Hero(window: PrayerWindow, now: Long, settings: Settings, hijri: String?, use24: Boolean) {
    val zone = settings.zone
    val next = window.next(now)
    val prev = window.previous(now)
    val city = settings.location?.label.orEmpty().ifBlank { stringResource(R.string.my_location) }
    val fraction = if (next != null && prev != null && next.second > prev.second) {
        ((now - prev.second).toFloat() / (next.second - prev.second)).coerceIn(0f, 1f)
    } else 0f
    val ring by animateFloatAsState(fraction, animationSpec = tween(900), label = "ring")

    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(32.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF138A66), Color(0xFF0B4A36), Color(0xFF062A1F))))
            .drawBehind {
                val c = Offset(size.width * 0.12f, size.height * 0.1f)
                for (i in 1..6) {
                    drawCircle(
                        color = Color.White.copy(alpha = 0.05f),
                        radius = size.width * 0.14f * i,
                        center = c,
                        style = Stroke(width = 2f),
                    )
                }
            }
            .padding(24.dp),
    ) {
        Column {
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.LocationOn, contentDescription = null, tint = Gold, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(city, color = Color.White.copy(alpha = 0.9f), style = MaterialTheme.typography.labelLarge)
                }
                if (hijri != null) Text(hijri, color = Gold, style = MaterialTheme.typography.labelLarge)
            }
            Spacer(Modifier.height(22.dp))
            if (next != null) {
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            stringResource(R.string.home_next),
                            color = Color.White.copy(alpha = 0.7f),
                            style = MaterialTheme.typography.labelMedium,
                        )
                        Text(
                            stringResource(next.first.label),
                            color = Color.White,
                            style = MaterialTheme.typography.displayMedium.copy(fontWeight = FontWeight.Bold),
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            stringResource(R.string.home_starts_at, formatClock(next.second, zone, use24)),
                            color = Color.White.copy(alpha = 0.85f),
                            style = MaterialTheme.typography.bodyLarge,
                        )
                    }
                    Box(Modifier.size(136.dp), contentAlignment = Alignment.Center) {
                        Canvas(Modifier.fillMaxSize()) {
                            val sw = 10.dp.toPx()
                            val arcSize = Size(size.width - sw, size.height - sw)
                            val topLeft = Offset(sw / 2, sw / 2)
                            drawArc(
                                color = Color.White.copy(alpha = 0.15f),
                                startAngle = -90f, sweepAngle = 360f, useCenter = false,
                                topLeft = topLeft, size = arcSize,
                                style = Stroke(width = sw, cap = StrokeCap.Round),
                            )
                            drawArc(
                                color = Gold,
                                startAngle = -90f, sweepAngle = 360f * ring, useCenter = false,
                                topLeft = topLeft, size = arcSize,
                                style = Stroke(width = sw, cap = StrokeCap.Round),
                            )
                        }
                        Text(
                            formatCountdown(next.second - now),
                            color = Color.White,
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, fontSize = 19.sp),
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MissionCard(store: AppStore, window: PrayerWindow, now: Long, today: LocalDate, isDone: Boolean) {
    val haptic = LocalHapticFeedback.current
    val t = window.today
    RCard(container = if (isDone) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface) {
        Text(
            stringResource(R.string.mission_title),
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
        )
        Spacer(Modifier.height(4.dp))
        val hint = when {
            isDone -> stringResource(R.string.mission_done)
            now in t.fajr..t.sunrise ->
                stringResource(R.string.mission_before_sunrise, formatCountdown(t.sunrise - now))
            else -> stringResource(R.string.mission_after)
        }
        Text(hint, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(12.dp))
        if (isDone) {
            TextButton(onClick = { store.setDone(today, false) }) { Text(stringResource(R.string.mission_undo)) }
        } else {
            Button(
                onClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    store.setDone(today, true)
                },
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().height(52.dp),
            ) { Text(stringResource(R.string.mission_confirm), style = MaterialTheme.typography.titleSmall) }
        }
    }
}

/** ذكر الصباح أو المساء بحسب وقت اليوم، والضغط على البطاقة يعدّ التكرار. */
@Composable
private fun DhikrCard(now: Long, zone: ZoneId) {
    val haptic = LocalHapticFeedback.current
    val morning = Instant.ofEpochMilli(now).atZone(zone).hour < 12
    val list = remember(morning) { AzkarData.list(if (morning) AzkarData.MORNING else AzkarData.EVENING) }
    var index by remember(morning) { mutableIntStateOf(0) }
    var count by remember(morning) { mutableIntStateOf(0) }
    val item = list.getOrNull(index) ?: return

    val advance: () -> Unit = {
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        if (count < item.repeat) {
            count++
        } else {
            index = (index + 1) % list.size
            count = 0
        }
    }

    RCard(Modifier.clip(RoundedCornerShape(24.dp)).clickable(onClick = advance)) {
        Text(
            stringResource(if (morning) R.string.dhikr_morning else R.string.dhikr_evening),
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.secondary,
        )
        Spacer(Modifier.height(10.dp))
        Text(item.text, style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.height(4.dp))
        Text(item.source, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text(
                "${count.ar()} / ${item.repeat.ar()}",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.primary,
            )
            Text(
                stringResource(if (count < item.repeat) R.string.dhikr_tap_count else R.string.dhikr_tap_next),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun StreakCard(done: Set<LocalDate>, today: LocalDate) {
    val current = Streaks.current(done, today)
    val best = Streaks.best(done)
    RCard {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly) {
            StatBlock(daysText(current), stringResource(R.string.streak_current), Modifier.weight(1f))
            StatBlock(
                daysText(best), stringResource(R.string.streak_best), Modifier.weight(1f),
                valueColor = MaterialTheme.colorScheme.secondary,
            )
        }
        Spacer(Modifier.height(16.dp))
        // الأقدم عند اليمين واليوم عند اليسار، وفق اتجاه القراءة
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
            for (back in 6 downTo 0) {
                val d = today.minusDays(back.toLong())
                DayDot(d.dayOfMonth, d in done, back == 0)
            }
        }
    }
}

@Composable
private fun DayDot(day: Int, done: Boolean, isToday: Boolean) {
    val scheme = MaterialTheme.colorScheme
    Box(
        Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(if (done) scheme.primary else Color.Transparent)
            .border(if (isToday) 2.dp else 1.dp, if (isToday) scheme.secondary else scheme.outlineVariant, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        if (done) {
            Icon(Icons.Filled.Check, contentDescription = null, tint = scheme.onPrimary, modifier = Modifier.size(18.dp))
        } else {
            Text(day.ar(), style = MaterialTheme.typography.labelMedium, color = scheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun TimesCard(window: PrayerWindow, now: Long, zone: ZoneId, use24: Boolean, settings: Settings, store: AppStore) {
    val next = window.next(now)
    val t = window.today
    RCard {
        Text(
            stringResource(R.string.home_times_title),
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
        )
        Text(
            stringResource(R.string.times_hint),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(8.dp))
        for (p in Prayer.entries) {
            val time = t.time(p)
            val canToggle = p != Prayer.SUNRISE
            val bellOn = canToggle && settings.adhanSound && p.name !in settings.adhanOff
            TimeRow(
                name = stringResource(p.label),
                clock = formatClock(time, zone, use24),
                highlighted = next != null && next.first == p && next.second == time,
                passed = time < now,
                showBell = canToggle,
                bellOn = bellOn,
                onBell = {
                    store.updateSettings { st ->
                        st.copy(
                            adhanSound = true,
                            adhanOff = if (p.name in st.adhanOff && st.adhanSound) st.adhanOff - p.name
                            else if (!st.adhanSound) st.adhanOff - p.name
                            else st.adhanOff + p.name,
                        )
                    }
                },
            )
        }
        TimeRow(
            name = stringResource(R.string.prayer_last_third),
            clock = formatClock(t.lastThird, zone, use24),
            highlighted = false,
            passed = t.lastThird < now,
            showBell = false,
            bellOn = false,
            onBell = {},
        )
    }
}

@Composable
private fun TimeRow(
    name: String, clock: String, highlighted: Boolean, passed: Boolean,
    showBell: Boolean, bellOn: Boolean, onBell: () -> Unit,
) {
    val scheme = MaterialTheme.colorScheme
    val textColor = when {
        highlighted -> Color.White
        passed -> scheme.onSurfaceVariant.copy(alpha = 0.6f)
        else -> scheme.onSurface
    }
    val weight = if (highlighted) FontWeight.Bold else FontWeight.Medium
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
            .clip(RoundedCornerShape(18.dp))
            .then(
                if (highlighted) Modifier.background(Brush.linearGradient(listOf(Color(0xFF138A66), Color(0xFF0B4A36))))
                else Modifier.background(scheme.surfaceVariant.copy(alpha = 0.45f)),
            )
            .padding(start = 16.dp, end = 4.dp, top = 2.dp, bottom = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(name, Modifier.weight(1f), color = textColor, fontWeight = weight, style = MaterialTheme.typography.titleMedium)
        Text(clock, color = if (highlighted) Gold else textColor, fontWeight = weight, style = MaterialTheme.typography.titleMedium)
        if (showBell) {
            IconButton(onClick = onBell) {
                Icon(
                    Icons.Filled.Notifications,
                    contentDescription = null,
                    tint = when {
                        bellOn && highlighted -> Gold
                        bellOn -> scheme.primary
                        else -> scheme.onSurfaceVariant.copy(alpha = 0.3f)
                    },
                )
            }
        } else {
            Spacer(Modifier.width(48.dp))
        }
    }
}

@Composable
private fun QiblaCard(lat: Double, lon: Double) {
    val ctx = LocalContext.current
    val bearing = remember(lat, lon) { Qibla(Coordinates(lat, lon)).direction.toFloat() }
    var azimuth by remember { mutableFloatStateOf(0f) }
    var hasSensor by remember { mutableStateOf(true) }

    DisposableEffect(Unit) {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        if (sensor == null) {
            hasSensor = false
            onDispose { }
        } else {
            val listener = object : SensorEventListener {
                val rot = FloatArray(9)
                val ori = FloatArray(3)
                override fun onSensorChanged(e: SensorEvent) {
                    SensorManager.getRotationMatrixFromVector(rot, e.values)
                    SensorManager.getOrientation(rot, ori)
                    val deg = (Math.toDegrees(ori[0].toDouble()).toFloat() + 360f) % 360f
                    var d = deg - azimuth
                    if (d > 180f) d -= 360f
                    if (d < -180f) d += 360f
                    azimuth = (azimuth + d * 0.2f + 360f) % 360f
                }
                override fun onAccuracyChanged(s: Sensor?, accuracy: Int) {}
            }
            sm.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_UI)
            onDispose { sm.unregisterListener(listener) }
        }
    }

    var diff = bearing - azimuth
    while (diff > 180f) diff -= 360f
    while (diff < -180f) diff += 360f
    val aligned = hasSensor && kotlin.math.abs(diff) < 5f
    val scheme = MaterialTheme.colorScheme
    val dialColor = scheme.primary
    val tickColor = scheme.onSurfaceVariant

    RCard {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    stringResource(R.string.qibla_title),
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    stringResource(R.string.qibla_body, bearing.toInt().ar()),
                    style = MaterialTheme.typography.bodySmall,
                    color = scheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    when {
                        !hasSensor -> stringResource(R.string.qibla_nosensor)
                        aligned -> stringResource(R.string.qibla_found)
                        else -> stringResource(R.string.qibla_hint)
                    },
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                    color = if (aligned) scheme.primary else scheme.secondary,
                )
            }
            Spacer(Modifier.width(12.dp))
            Canvas(Modifier.size(150.dp)) {
                val c = Offset(size.width / 2, size.height / 2)
                val r = size.minDimension / 2 - 8.dp.toPx()
                rotate(degrees = -azimuth, pivot = c) {
                    drawCircle(color = dialColor.copy(alpha = 0.10f), radius = r, center = c)
                    drawCircle(color = dialColor, radius = r, center = c, style = Stroke(width = 3.dp.toPx()))
                    for (k in 0 until 12) {
                        val a = Math.toRadians((k * 30 - 90).toDouble())
                        val len = if (k == 0) 14.dp.toPx() else 8.dp.toPx()
                        val p1 = Offset(c.x + (r - len) * cos(a).toFloat(), c.y + (r - len) * sin(a).toFloat())
                        val p2 = Offset(c.x + r * cos(a).toFloat(), c.y + r * sin(a).toFloat())
                        drawLine(
                            color = if (k == 0) Color(0xFFD64545) else tickColor,
                            start = p1, end = p2,
                            strokeWidth = if (k == 0) 4.dp.toPx() else 2.dp.toPx(),
                        )
                    }
                    val qa = Math.toRadians((bearing - 90f).toDouble())
                    val tip = Offset(c.x + (r - 6.dp.toPx()) * cos(qa).toFloat(), c.y + (r - 6.dp.toPx()) * sin(qa).toFloat())
                    drawLine(color = Gold, start = c, end = tip, strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)
                    drawCircle(color = Gold, radius = 11.dp.toPx(), center = tip)
                }
                // مثلث ثابت يمثل اتجاه الهاتف
                drawLine(
                    color = if (aligned) dialColor else scheme.onSurface,
                    start = Offset(c.x, c.y - r - 2.dp.toPx()),
                    end = Offset(c.x, c.y - r + 18.dp.toPx()),
                    strokeWidth = 4.dp.toPx(), cap = StrokeCap.Round,
                )
                drawCircle(color = dialColor, radius = 5.dp.toPx(), center = c)
            }
        }
    }
}
