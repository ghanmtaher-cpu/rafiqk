package com.rafiqk.app.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.time.LocalDate
import java.time.ZoneId

data class GeoPoint(val lat: Double, val lon: Double, val tzId: String, val label: String)

data class Settings(
    val location: GeoPoint? = null,
    val method: String = "UMM_AL_QURA",
    val hanafi: Boolean = false,
    val lastThird: Boolean = true,
    val afterFajr: Boolean = true,
    val afterFajrDelayMin: Int = 25,
    val eveningAzkar: Boolean = true,
    val beforeIftar: Boolean = true,
    val fastEve: Boolean = true,
    val friday: Boolean = true,
    val kahf: Boolean = true,
    val adhanSound: Boolean = false,
) {
    /** المنطقة الزمنية للموقع المختار، وإلا منطقة الجهاز. */
    val zone: ZoneId
        get() = location?.tzId?.let { runCatching { ZoneId.of(it) }.getOrNull() } ?: ZoneId.systemDefault()
}

private object K {
    const val DONE = "done_dates"
    const val LAT = "loc_lat"
    const val LON = "loc_lon"
    const val TZ = "loc_tz"
    const val LABEL = "loc_label"
    const val METHOD = "calc_method"
    const val HANAFI = "hanafi"
    // مفاتيح قديمة محفوظة للتوافق مع نسخة 1.x
    const val LAST_THIRD = "enable_last_third"
    const val AFTER_FAJR = "enable_fajr"
    const val IFTAR = "enable_before_iftar"
    const val FAST_EVE = "enable_mon_thu"
    const val FRIDAY = "enable_friday"
    const val KAHF = "enable_kahf"
    const val ADHAN = "enable_adhan_sound"
    // مفاتيح جديدة
    const val EVENING = "enable_evening"
    const val DELAY = "fajr_delay_min"
}

/** مخزن بسيط وآمن للخيوط: الإعدادات وأيام الإنجاز، مع StateFlow للواجهة. */
class AppStore private constructor(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("rafiqk", Context.MODE_PRIVATE)
    private val lock = Any()

    private val _settings = MutableStateFlow(readSettings())
    private val _done = MutableStateFlow(readDone())

    val settings: StateFlow<Settings> = _settings.asStateFlow()
    val doneDates: StateFlow<Set<LocalDate>> = _done.asStateFlow()

    fun updateSettings(transform: (Settings) -> Settings) {
        synchronized(lock) {
            val current = _settings.value
            val next = transform(current)
            if (next == current) return
            _settings.value = next
            writeSettings(next)
        }
    }

    fun setDone(date: LocalDate, done: Boolean) {
        synchronized(lock) {
            val next = _done.value.toMutableSet()
            if (done) next.add(date) else next.remove(date)
            _done.value = next
            prefs.edit().putStringSet(K.DONE, next.map { it.toString() }.toSet()).commit()
        }
    }

    private fun readDone(): Set<LocalDate> =
        prefs.getStringSet(K.DONE, emptySet())
            ?.mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }
            ?.toSet()
            ?: emptySet()

    private fun legacy(key: String): Double? =
        (prefs.all[key] as? Float)?.toDouble()?.takeIf { it != 0.0 }

    private fun readSettings(): Settings {
        val d = Settings()
        val lat = prefs.getString(K.LAT, null)?.toDoubleOrNull() ?: legacy("lat")
        val lon = prefs.getString(K.LON, null)?.toDoubleOrNull() ?: legacy("lon")
        val location =
            if (lat != null && lon != null && lat in -90.0..90.0 && lon in -180.0..180.0) {
                GeoPoint(
                    lat, lon,
                    prefs.getString(K.TZ, null) ?: ZoneId.systemDefault().id,
                    prefs.getString(K.LABEL, null) ?: "",
                )
            } else null
        return Settings(
            location = location,
            method = prefs.getString(K.METHOD, null) ?: d.method,
            hanafi = prefs.getBoolean(K.HANAFI, d.hanafi),
            lastThird = prefs.getBoolean(K.LAST_THIRD, d.lastThird),
            afterFajr = prefs.getBoolean(K.AFTER_FAJR, d.afterFajr),
            afterFajrDelayMin = prefs.getInt(K.DELAY, d.afterFajrDelayMin),
            eveningAzkar = prefs.getBoolean(K.EVENING, d.eveningAzkar),
            beforeIftar = prefs.getBoolean(K.IFTAR, d.beforeIftar),
            fastEve = prefs.getBoolean(K.FAST_EVE, d.fastEve),
            friday = prefs.getBoolean(K.FRIDAY, d.friday),
            kahf = prefs.getBoolean(K.KAHF, d.kahf),
            adhanSound = prefs.getBoolean(K.ADHAN, d.adhanSound),
        )
    }

    private fun writeSettings(s: Settings) {
        val e = prefs.edit()
        val l = s.location
        if (l != null) {
            e.putString(K.LAT, l.lat.toString())
            e.putString(K.LON, l.lon.toString())
            e.putString(K.TZ, l.tzId)
            e.putString(K.LABEL, l.label)
        } else {
            e.remove(K.LAT).remove(K.LON).remove(K.TZ).remove(K.LABEL)
        }
        e.putString(K.METHOD, s.method)
        e.putBoolean(K.HANAFI, s.hanafi)
        e.putBoolean(K.LAST_THIRD, s.lastThird)
        e.putBoolean(K.AFTER_FAJR, s.afterFajr)
        e.putInt(K.DELAY, s.afterFajrDelayMin)
        e.putBoolean(K.EVENING, s.eveningAzkar)
        e.putBoolean(K.IFTAR, s.beforeIftar)
        e.putBoolean(K.FAST_EVE, s.fastEve)
        e.putBoolean(K.FRIDAY, s.friday)
        e.putBoolean(K.KAHF, s.kahf)
        e.putBoolean(K.ADHAN, s.adhanSound)
        e.apply()
    }

    companion object {
        @Volatile
        private var instance: AppStore? = null

        fun get(context: Context): AppStore =
            instance ?: synchronized(this) {
                instance ?: AppStore(context.applicationContext).also { instance = it }
            }
    }
}
