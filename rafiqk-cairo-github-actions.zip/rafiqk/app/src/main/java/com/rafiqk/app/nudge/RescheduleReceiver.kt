package com.rafiqk.app.nudge

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** يعيد الجدولة عند الإقلاع وتحديث التطبيق وتغيّر الوقت أو المنطقة وبمنبّه منتصف الليل. */
class RescheduleReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Scheduler.rescheduleAll(context)
    }
}
