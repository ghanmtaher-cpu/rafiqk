package com.rafiqk.app.prayer

import com.rafiqk.app.util.toArabicDigits
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.chrono.HijrahDate
import java.time.temporal.ChronoField

enum class FastReason { MON_THU, WHITE_DAY, RAMADAN }

/** التقويم الهجري (أم القرى). قد يختلف يوماً عن الرؤية المحلية في بلدك. */
object HijriCalendar {

    private val months = arrayOf(
        "محرم", "صفر", "ربيع الأول", "ربيع الآخر", "جمادى الأولى", "جمادى الآخرة",
        "رجب", "شعبان", "رمضان", "شوال", "ذو القعدة", "ذو الحجة",
    )

    private fun parts(date: LocalDate): Triple<Int, Int, Int>? = runCatching {
        val h = HijrahDate.from(date)
        Triple(
            h.get(ChronoField.YEAR),
            h.get(ChronoField.MONTH_OF_YEAR),
            h.get(ChronoField.DAY_OF_MONTH),
        )
    }.getOrNull()

    fun format(date: LocalDate): String? {
        val (y, m, d) = parts(date) ?: return null
        return "$d ${months[m - 1]} $y هـ".toArabicDigits()
    }

    /** سبب استحباب صيام هذا اليوم، أو null إن لم يكن يوم صيام (أو كان صيامه محرّماً كالعيدين وأيام التشريق). */
    fun fastReason(date: LocalDate): FastReason? {
        val p = parts(date)
        if (p != null) {
            val (_, m, d) = p
            if ((m == 10 && d == 1) || (m == 12 && d in 10..13)) return null
            if (m == 9) return FastReason.RAMADAN
            if (d in 13..15) return FastReason.WHITE_DAY
        }
        return if (date.dayOfWeek == DayOfWeek.MONDAY || date.dayOfWeek == DayOfWeek.THURSDAY) {
            FastReason.MON_THU
        } else null
    }
}
