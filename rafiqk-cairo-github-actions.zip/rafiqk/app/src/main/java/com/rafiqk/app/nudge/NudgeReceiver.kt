package com.rafiqk.app.nudge

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationManagerCompat
import com.rafiqk.app.data.AppStore
import java.time.LocalDate

class NudgeReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        val store = AppStore.get(app)

        // زر "تم" في الإشعار
        if (intent.action == ACTION_CONFIRM) {
            store.setDone(LocalDate.now(store.settings.value.zone), true)
            val nm = NotificationManagerCompat.from(app)
            nm.cancel(NudgeKind.AFTER_FAJR.code)
            nm.cancel(NudgeKind.FAJR_FOLLOWUP.code)
            return
        }

        val kind = NudgeKind.fromId(intent.getStringExtra(EXTRA_KIND)) ?: return
        val arg = intent.getStringExtra(EXTRA_ARG)
        try {
            val doneToday = LocalDate.now(store.settings.value.zone) in store.doneDates.value
            when {
                kind.isAdhan -> Notifier.startAdhan(app, arg)
                kind == NudgeKind.FAJR_FOLLOWUP && doneToday -> Unit
                else -> Notifier.showNudge(app, kind, arg)
            }
        } finally {
            // يحافظ على نافذة الجدولة المتحركة حتى لو فشل منبّه الصيانة
            Scheduler.rescheduleAll(app)
        }
    }

    companion object {
        const val EXTRA_KIND = "kind"
        const val EXTRA_ARG = "arg"
        const val ACTION_CONFIRM = "com.rafiqk.app.CONFIRM_SITTING"
    }
}
