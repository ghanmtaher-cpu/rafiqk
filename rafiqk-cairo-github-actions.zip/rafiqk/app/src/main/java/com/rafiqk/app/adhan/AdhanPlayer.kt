package com.rafiqk.app.adhan

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.PowerManager

/**
 * يشغّل ملف res/raw/takbir_short إن وُجد (بدونه لا يُشغَّل شيء ولا يتعطل التطبيق).
 * تأكد أن الملف الصوتي مرخّص لك للاستخدام في تطبيق منشور.
 */
object AdhanPlayer {
    private var player: MediaPlayer? = null

    @Synchronized
    fun play(context: Context, onDone: () -> Unit) {
        stop()
        val app = context.applicationContext
        val resId = app.resources.getIdentifier("takbir_short", "raw", app.packageName)
        if (resId == 0) {
            onDone()
            return
        }
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()
        val session = app.getSystemService(AudioManager::class.java).generateAudioSessionId()
        val mp = MediaPlayer.create(app, resId, attrs, session)
        if (mp == null) {
            onDone()
            return
        }
        mp.setWakeMode(app, PowerManager.PARTIAL_WAKE_LOCK)
        mp.setOnCompletionListener {
            stop()
            onDone()
        }
        mp.setOnErrorListener { _, _, _ ->
            stop()
            onDone()
            true
        }
        player = mp
        mp.start()
    }

    @Synchronized
    fun stop() {
        player?.runCatching { release() }
        player = null
    }
}
