package com.rafiqk.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalLayoutDirection
import com.rafiqk.app.R

private val LightColors = lightColorScheme(
    primary = Color(0xFF0F5C45),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD5EADF),
    onPrimaryContainer = Color(0xFF06382A),
    secondary = Color(0xFF8A6414),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFF6E8C3),
    onSecondaryContainer = Color(0xFF4A3507),
    tertiary = Color(0xFFC9A24B),
    background = Color(0xFFF7F3EA),
    onBackground = Color(0xFF1B2A24),
    surface = Color(0xFFFFFDF8),
    onSurface = Color(0xFF1B2A24),
    surfaceVariant = Color(0xFFEFE9DA),
    onSurfaceVariant = Color(0xFF5C6B64),
    outline = Color(0xFFB9B2A0),
    outlineVariant = Color(0xFFE3DCCB),
    error = Color(0xFFB3261E),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF58C9A0),
    onPrimary = Color(0xFF06382A),
    primaryContainer = Color(0xFF14483A),
    onPrimaryContainer = Color(0xFFC8EBDC),
    secondary = Color(0xFFE3B94F),
    onSecondary = Color(0xFF3B2A00),
    secondaryContainer = Color(0xFF4A3A10),
    onSecondaryContainer = Color(0xFFF6E8C3),
    tertiary = Color(0xFFE3B94F),
    background = Color(0xFF0C1612),
    onBackground = Color(0xFFE9EFEA),
    surface = Color(0xFF14221C),
    onSurface = Color(0xFFE9EFEA),
    surfaceVariant = Color(0xFF1F312A),
    onSurfaceVariant = Color(0xFF9DB0A7),
    outline = Color(0xFF51635A),
    outlineVariant = Color(0xFF27382F),
    error = Color(0xFFF2B8B5),
)

// خط Cairo: ضع cairo.ttf (يفضّل النسخة المتغيّرة Variable) في res/font
private val Cairo = FontFamily(
    Font(R.font.cairo, FontWeight.Normal),
    Font(R.font.cairo, FontWeight.Medium),
    Font(R.font.cairo, FontWeight.SemiBold),
    Font(R.font.cairo, FontWeight.Bold),
)

private fun TextStyle.cairo(lineHeight: Int? = null): TextStyle =
    copy(fontFamily = Cairo, lineHeight = lineHeight?.sp ?: this.lineHeight)

private val base = Typography()

private val AppTypography = Typography(
    displayLarge = base.displayLarge.cairo(),
    displayMedium = base.displayMedium.cairo(),
    displaySmall = base.displaySmall.cairo(),
    headlineLarge = base.headlineLarge.cairo(),
    headlineMedium = base.headlineMedium.cairo(),
    headlineSmall = base.headlineSmall.cairo(),
    titleLarge = base.titleLarge.cairo(),
    titleMedium = base.titleMedium.cairo(),
    titleSmall = base.titleSmall.cairo(),
    bodyLarge = base.bodyLarge.cairo(lineHeight = 30),
    bodyMedium = base.bodyMedium.cairo(lineHeight = 24),
    bodySmall = base.bodySmall.cairo(lineHeight = 20),
    labelLarge = base.labelLarge.cairo(),
    labelMedium = base.labelMedium.cairo(),
    labelSmall = base.labelSmall.cairo(),
)

@Composable
fun RafiqkTheme(content: @Composable () -> Unit) {
    val colors = if (isSystemInDarkTheme()) DarkColors else LightColors
    // التطبيق عربي بالكامل: نثبّت الاتجاه من اليمين لليسار مهما كانت لغة الجهاز
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(colorScheme = colors, typography = AppTypography, content = content)
    }
}
