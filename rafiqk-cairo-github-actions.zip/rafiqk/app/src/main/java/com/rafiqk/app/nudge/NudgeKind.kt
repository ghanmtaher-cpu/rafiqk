package com.rafiqk.app.nudge

import com.rafiqk.app.data.AzkarData

enum class NudgeKind(val id: String, val code: Int, val scene: String) {
    LAST_THIRD("last_third", 10, AzkarData.LAST_THIRD),
    AFTER_FAJR("after_fajr", 20, AzkarData.SIT_FAJR),
    FAJR_FOLLOWUP("fajr_followup", 21, AzkarData.SIT_FAJR),
    EVENING_AZKAR("evening_azkar", 30, AzkarData.EVENING),
    BEFORE_IFTAR("before_iftar", 40, AzkarData.BEFORE_IFTAR),
    FAST_EVE("fast_eve", 50, AzkarData.FAST_MON_THU),
    FRIDAY_HOUR("friday_hour", 60, AzkarData.FRIDAY_HOUR),
    KAHF("kahf", 70, AzkarData.KAHF),
    ADHAN_FAJR("adhan_fajr", 90, ""),
    ADHAN_DHUHR("adhan_dhuhr", 91, ""),
    ADHAN_ASR("adhan_asr", 92, ""),
    ADHAN_MAGHRIB("adhan_maghrib", 93, ""),
    ADHAN_ISHA("adhan_isha", 94, "");

    val isAdhan: Boolean get() = id.startsWith("adhan_")

    companion object {
        fun fromId(id: String?): NudgeKind? = NudgeKind.entries.firstOrNull { it.id == id }
    }
}
