package com.rafiqk.app.data

import java.time.LocalDate
import java.time.YearMonth

object Streaks {

    /** السلسلة الحالية: إن لم يُسجَّل اليوم بعد، تُحتسب من الأمس حتى لا تنكسر قبل نهاية اليوم. */
    fun current(done: Set<LocalDate>, today: LocalDate): Int {
        var d = if (today in done) today else today.minusDays(1)
        var n = 0
        while (d in done) {
            n++
            d = d.minusDays(1)
        }
        return n
    }

    fun best(done: Set<LocalDate>): Int {
        var best = 0
        var run = 0
        var prev: LocalDate? = null
        for (d in done.sorted()) {
            run = if (prev != null && d == prev.plusDays(1)) run + 1 else 1
            if (run > best) best = run
            prev = d
        }
        return best
    }

    fun inMonth(done: Set<LocalDate>, month: YearMonth): Int =
        done.count { YearMonth.from(it) == month }
}
