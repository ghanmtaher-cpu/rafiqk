package com.rafiqk.app.nudge

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.annotation.StringRes
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.rafiqk.app.MainActivity
import com.rafiqk.app.R
import com.rafiqk.app.adhan.AdhanService
import com.rafiqk.app.data.AzkarData
import com.rafiqk.app.prayer.Prayer
import com.rafiqk.app.util.ar
import java.time.LocalDate

object Notifier {

    const val CH_NUDGE = "rafiqk_nudges_v2"
    const val CH_ADHAN = "rafiqk_adhan"

    fun ensureChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(
            NotificationChannel(CH_NUDGE, ctx.getString(R.string.channel_nudges), NotificationManager.IMPORTANCE_HIGH)
                .apply { description = ctx.getString(R.string.channel_nudges_desc) },
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_ADHAN, ctx.getString(R.string.channel_adhan), NotificationManager.IMPORTANCE_LOW),
        )
    }

    @StringRes
    private fun titleFor(kind: NudgeKind): Int = when (kind) {
        NudgeKind.LAST_THIRD -> R.string.nudge_last_third
        NudgeKind.AFTER_FAJR -> R.string.nudge_after_fajr
        NudgeKind.FAJR_FOLLOWUP -> R.string.nudge_followup
        NudgeKind.EVENING_AZKAR -> R.string.nudge_evening
        NudgeKind.BEFORE_IFTAR -> R.string.nudge_iftar
        NudgeKind.FAST_EVE -> R.string.nudge_fast_eve
        NudgeKind.FRIDAY_HOUR -> R.string.nudge_friday
        NudgeKind.KAHF -> R.string.nudge_kahf
        else -> R.string.app_name
    }

    private fun openApp(ctx: Context): PendingIntent = PendingIntent.getActivity(
        ctx, 0, Intent(ctx, MainActivity::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
    )

    private fun confirmIntent(ctx: Context): PendingIntent = PendingIntent.getBroadcast(
        ctx, 1, Intent(ctx, NudgeReceiver::class.java).setAction(NudgeReceiver.ACTION_CONFIRM),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
    )

    fun showNudge(ctx: Context, kind: NudgeKind, arg: String?) {
        ensureChannels(ctx)
        val nm = NotificationManagerCompat.from(ctx)
        if (!nm.areNotificationsEnabled()) return

        val scene = if (kind == NudgeKind.FAST_EVE && arg != null) arg else kind.scene
        val d = AzkarData.pick(scene, LocalDate.now().toEpochDay() + kind.code) ?: AzkarData.fallback
        val repeat = if (d.repeat > 1) "\n" + ctx.getString(R.string.repeat_times, d.repeat.ar()) else ""
        val big = d.text + repeat + "\n— " + d.source

        val b = NotificationCompat.Builder(ctx, CH_NUDGE)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(ContextCompat.getColor(ctx, R.color.brand))
            .setContentTitle(ctx.getString(titleFor(kind)))
            .setContentText(d.text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(big))
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(openApp(ctx))
        if (kind == NudgeKind.AFTER_FAJR || kind == NudgeKind.FAJR_FOLLOWUP) {
            b.addAction(0, ctx.getString(R.string.action_done), confirmIntent(ctx))
        }
        try {
            nm.notify(kind.code, b.build())
        } catch (e: SecurityException) {
            // إذن الإشعارات غير ممنوح
        }
    }

    fun startAdhan(ctx: Context, prayerName: String?) {
        ensureChannels(ctx)
        val intent = Intent(ctx, AdhanService::class.java).putExtra(AdhanService.EXTRA_PRAYER, prayerName)
        try {
            ContextCompat.startForegroundService(ctx, intent)
        } catch (e: Exception) {
            // منع النظام تشغيل الخدمة من الخلفية: نكتفي بإشعار عادي
            val p = prayerName?.let { runCatching { Prayer.valueOf(it) }.getOrNull() }
            val name = p?.let { ctx.getString(it.label) }.orEmpty()
            val n = NotificationCompat.Builder(ctx, CH_NUDGE)
                .setSmallIcon(R.drawable.ic_notification)
                .setColor(ContextCompat.getColor(ctx, R.color.brand))
                .setContentTitle(ctx.getString(R.string.adhan_title, name))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(openApp(ctx))
                .build()
            try {
                NotificationManagerCompat.from(ctx).notify(NudgeKind.ADHAN_FAJR.code + 100, n)
            } catch (se: SecurityException) {
            }
        }
    }
}
