package com.rafiqk.app.ui

import android.Manifest
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.rafiqk.app.R
import com.rafiqk.app.data.AppStore
import com.rafiqk.app.data.Cities
import com.rafiqk.app.data.City
import com.rafiqk.app.location.LocationProvider
import kotlinx.coroutines.launch

class GpsAction(val busy: Boolean, val run: () -> Unit)

/** طلب إذن الموقع التقريبي ثم تحديد الموقع وحفظه. */
@Composable
fun rememberGpsAction(store: AppStore): GpsAction {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }

    fun fetch() {
        scope.launch {
            busy = true
            val point = LocationProvider.current(ctx)
            busy = false
            if (point != null) {
                store.updateSettings { it.copy(location = point) }
            } else {
                Toast.makeText(ctx, R.string.location_failed, Toast.LENGTH_LONG).show()
            }
        }
    }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) fetch() else Toast.makeText(ctx, R.string.location_denied, Toast.LENGTH_LONG).show()
    }

    return GpsAction(busy) {
        if (LocationProvider.hasPermission(ctx)) fetch()
        else launcher.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
    }
}

@Composable
fun CityPickerDialog(onPick: (City) -> Unit, onDismiss: () -> Unit) {
    var query by remember { mutableStateOf("") }
    val shown = remember(query) {
        val q = query.trim()
        if (q.isEmpty()) Cities.all else Cities.all.filter { it.name.contains(q) }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.close)) } },
        title = { Text(stringResource(R.string.city_picker_title)) },
        text = {
            Column {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    placeholder = { Text(stringResource(R.string.city_search_hint)) },
                    modifier = Modifier.fillMaxWidth(),
                )
                LazyColumn(Modifier.height(300.dp)) {
                    items(shown, key = { it.name }) { city ->
                        Text(
                            city.name,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onPick(city)
                                    onDismiss()
                                }
                                .padding(vertical = 14.dp, horizontal = 4.dp),
                        )
                    }
                }
            }
        },
    )
}
