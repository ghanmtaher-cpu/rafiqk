package com.rafiqk.app.util

import java.time.Instant
import java.time.ZoneId
import java.util.Locale

/** يحوّل الأرقام اللاتينية إلى هندية (٠١٢٣…) ليبقى النص متسقاً أياً كان لغة الجهاز. */
fun String.toArabicDigits(): String {
    val sb = StringBuilder(length)
    for (c in this) sb.append(if (c in '0'..'9') ('٠' + (c - '0')) else c)
    return sb.toString()
}

fun Int.ar(): String = toString().toArabicDigits()

fun formatClock(millis: Long, zone: ZoneId, use24h: Boolean): String {
    val t = Instant.ofEpochMilli(millis).atZone(zone)
    val h = t.hour
    val mm = t.minute.toString().padStart(2, '0')
    return if (use24h) {
        "${h.toString().padStart(2, '0')}:$mm".toArabicDigits()
    } else {
        val h12 = if (h % 12 == 0) 12 else h % 12
        "$h12:$mm ${if (h < 12) "ص" else "م"}".toArabicDigits()
    }
}

fun formatCountdown(ms: Long): String {
    val total = (ms.coerceAtLeast(0L) + 999L) / 1000L
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return String.format(Locale.ROOT, "%02d:%02d:%02d", h, m, s).toArabicDigits()
}
