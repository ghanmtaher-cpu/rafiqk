package com.rafiqk.app.prayer

import androidx.annotation.StringRes
import com.batoulapps.adhan.CalculationMethod
import com.batoulapps.adhan.CalculationParameters
import com.batoulapps.adhan.Coordinates
import com.batoulapps.adhan.Madhab
import com.batoulapps.adhan.PrayerTimes
import com.batoulapps.adhan.SunnahTimes
import com.batoulapps.adhan.data.DateComponents
import com.rafiqk.app.R
import com.rafiqk.app.data.Settings
import java.time.LocalDate
import java.time.ZoneId

enum class Prayer(@StringRes val label: Int) {
    FAJR(R.string.prayer_fajr),
    SUNRISE(R.string.prayer_sunrise),
    DHUHR(R.string.prayer_dhuhr),
    ASR(R.string.prayer_asr),
    MAGHRIB(R.string.prayer_maghrib),
    ISHA(R.string.prayer_isha),
}

/** أوقات يوم واحد بالميلي ثانية. lastThird = الثلث الأخير من الليلة التي تنتهي بفجر هذا اليوم. */
data class DayTimes(
    val date: LocalDate,
    val zone: ZoneId,
    val fajr: Long,
    val sunrise: Long,
    val dhuhr: Long,
    val asr: Long,
    val maghrib: Long,
    val isha: Long,
    val lastThird: Long,
) {
    fun time(p: Prayer): Long = when (p) {
        Prayer.FAJR -> fajr
        Prayer.SUNRISE -> sunrise
        Prayer.DHUHR -> dhuhr
        Prayer.ASR -> asr
        Prayer.MAGHRIB -> maghrib
        Prayer.ISHA -> isha
    }

    val events: List<Pair<Prayer, Long>> get() = Prayer.entries.map { it to time(it) }
}

/** أمس واليوم وغداً: لإيجاد "التالية" و"السابقة" عبر منتصف الليل بلا حالات خاصة. */
class PrayerWindow(val yesterday: DayTimes, val today: DayTimes, val tomorrow: DayTimes) {
    private val all: List<Pair<Prayer, Long>> =
        (yesterday.events + today.events + tomorrow.events).sortedBy { it.second }

    fun next(now: Long): Pair<Prayer, Long>? = all.firstOrNull { it.second > now }
    fun previous(now: Long): Pair<Prayer, Long>? = all.lastOrNull { it.second <= now }
}

object PrayerEngine {

    private fun params(s: Settings): CalculationParameters {
        val method = runCatching { CalculationMethod.valueOf(s.method) }
            .getOrDefault(CalculationMethod.UMM_AL_QURA)
        val p = method.parameters
        if (s.hanafi) p.madhab = Madhab.HANAFI
        return p
    }

    fun day(s: Settings, date: LocalDate): DayTimes? {
        val loc = s.location ?: return null
        return try {
            val coords = Coordinates(loc.lat, loc.lon)
            val p = params(s)
            fun times(d: LocalDate) =
                PrayerTimes(coords, DateComponents(d.year, d.monthValue, d.dayOfMonth), p)

            val t = times(date)
            // الليلة التي تنتهي بفجر اليوم تبدأ بمغرب الأمس
            val night = SunnahTimes(times(date.minusDays(1)))
            DayTimes(
                date = date,
                zone = s.zone,
                fajr = t.fajr.time,
                sunrise = t.sunrise.time,
                dhuhr = t.dhuhr.time,
                asr = t.asr.time,
                maghrib = t.maghrib.time,
                isha = t.isha.time,
                lastThird = night.lastThirdOfTheNight.time,
            )
        } catch (e: Exception) {
            null
        }
    }

    fun window(s: Settings, today: LocalDate): PrayerWindow? {
        val y = day(s, today.minusDays(1)) ?: return null
        val t = day(s, today) ?: return null
        val n = day(s, today.plusDays(1)) ?: return null
        return PrayerWindow(y, t, n)
    }
}
