package com.rafiqk.app.location

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.CancellationSignal
import androidx.core.content.ContextCompat
import com.rafiqk.app.R
import com.rafiqk.app.data.Cities
import com.rafiqk.app.data.GeoPoint
import com.rafiqk.app.util.toArabicDigits
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import java.time.ZoneId
import java.util.Locale
import kotlin.coroutines.resume

object LocationProvider {

    private const val FRESH_MS = 6L * 60 * 60 * 1000

    fun hasPermission(ctx: Context): Boolean =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED

    suspend fun current(ctx: Context): GeoPoint? {
        if (!hasPermission(ctx)) return null
        val lm = ctx.getSystemService(LocationManager::class.java) ?: return null
        val cached = lastKnown(lm)
        val isFresh = cached != null && System.currentTimeMillis() - cached.time < FRESH_MS
        val found: Location? =
            if (isFresh) cached else (withTimeoutOrNull(10_000L) { fresh(ctx, lm) } ?: cached)
        val loc = found ?: return null
        if (loc.latitude !in -90.0..90.0 || loc.longitude !in -180.0..180.0) return null
        return GeoPoint(loc.latitude, loc.longitude, ZoneId.systemDefault().id, labelFor(ctx, loc))
    }

    private fun labelFor(ctx: Context, loc: Location): String {
        val (city, km) = Cities.nearest(loc.latitude, loc.longitude)
        return if (km < 60.0) {
            city.name
        } else {
            val coords = String.format(Locale.ROOT, "%.2f، %.2f", loc.latitude, loc.longitude).toArabicDigits()
            ctx.getString(R.string.my_location_coords, coords)
        }
    }

    @SuppressLint("MissingPermission")
    private fun lastKnown(lm: LocationManager): Location? =
        listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER, LocationManager.PASSIVE_PROVIDER)
            .mapNotNull { p -> runCatching { lm.getLastKnownLocation(p) }.getOrNull() }
            .maxByOrNull { it.time }

    @SuppressLint("MissingPermission")
    private suspend fun fresh(ctx: Context, lm: LocationManager): Location? {
        if (Build.VERSION.SDK_INT < 30) return null
        return suspendCancellableCoroutine<Location?> { cont ->
            val signal = CancellationSignal()
            cont.invokeOnCancellation { signal.cancel() }
            try {
                lm.getCurrentLocation(
                    LocationManager.NETWORK_PROVIDER, signal, ContextCompat.getMainExecutor(ctx),
                ) { loc -> if (cont.isActive) cont.resume(loc) }
            } catch (e: Exception) {
                if (cont.isActive) cont.resume(null)
            }
        }
    }
}
