package com.rafiqk.app

import android.app.Application
import com.rafiqk.app.nudge.Notifier

class RafiqkApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Notifier.ensureChannels(this)
    }
}
