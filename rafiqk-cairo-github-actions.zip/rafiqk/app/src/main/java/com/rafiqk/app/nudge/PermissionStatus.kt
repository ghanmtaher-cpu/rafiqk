package com.rafiqk.app.nudge

import android.app.AlarmManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationManagerCompat

object PermissionStatus {
    fun notificationsOk(ctx: Context): Boolean =
        NotificationManagerCompat.from(ctx).areNotificationsEnabled()

    fun exactAlarmsOk(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 31 ||
            (ctx.getSystemService(AlarmManager::class.java)?.canScheduleExactAlarms() ?: true)
}
