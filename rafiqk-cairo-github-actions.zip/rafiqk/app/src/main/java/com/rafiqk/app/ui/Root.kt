package com.rafiqk.app.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import com.rafiqk.app.R
import com.rafiqk.app.data.AppStore

private data class Tab(val label: Int, val icon: ImageVector)

private val TABS = listOf(
    Tab(R.string.tab_home, Icons.Filled.Home),
    Tab(R.string.tab_history, Icons.Filled.DateRange),
    Tab(R.string.tab_settings, Icons.Filled.Settings),
)

@Composable
fun RafiqkRoot(store: AppStore, refreshKey: Int) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val scheme = MaterialTheme.colorScheme
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(scheme.background, scheme.primaryContainer.copy(alpha = 0.5f)))),
    ) {
        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = {
                NavigationBar(containerColor = scheme.surface, tonalElevation = 8.dp) {
                    TABS.forEachIndexed { i, t ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Icon(t.icon, contentDescription = null) },
                            label = { Text(stringResource(t.label)) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.White,
                                selectedTextColor = scheme.primary,
                                indicatorColor = scheme.primary,
                                unselectedIconColor = scheme.onSurfaceVariant,
                                unselectedTextColor = scheme.onSurfaceVariant,
                            ),
                        )
                    }
                }
            },
        ) { inner ->
            Box(Modifier.padding(inner)) {
                Crossfade(targetState = tab, animationSpec = tween(350), label = "tabs") { current ->
                    when (current) {
                        0 -> HomeScreen(store, refreshKey, onOpenSettings = { tab = 2 })
                        1 -> HistoryScreen(store)
                        else -> SettingsScreen(store, refreshKey)
                    }
                }
            }
        }
    }
}
